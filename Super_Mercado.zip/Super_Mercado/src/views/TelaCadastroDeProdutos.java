package views;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.EmptyBorder;

public class TelaCadastroDeProdutos extends JPanel {

    private static final long serialVersionUID = 1L;

    private JButton btn_adicionar;
    private JButton btnVoltar;

    private JTextField textID;
    private JTextField textnome;
    private JTextField textDesc;
    private JTextField textQtd;
    private JTextField textpreco;

    private JTable tabelaProdutos;
    private DefaultTableModel modeloTabela;

    public TelaCadastroDeProdutos() {

        setBackground(Color.WHITE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // -----------------------------------------------------
        // TÍTULO
        // -----------------------------------------------------
        JLabel lblTitulo = new JLabel("CADASTRAR PRODUTO");
        lblTitulo.setFont(new Font("Segoe UI Black", Font.PLAIN, 30)); // tamanho maior
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        add(lblTitulo, gbc);

        // -----------------------------------------------------
        // BOTÃO VOLTAR
        // -----------------------------------------------------
        btnVoltar = new JButton("Voltar");
        btnVoltar.setFont(new Font("Segoe UI", Font.PLAIN, 18)); // maior
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        add(btnVoltar, gbc);

        // -----------------------------------------------------
        // CAMPOS (AGORA COM TAMANHOS MÍNIMOS REAIS)
        // -----------------------------------------------------

        addLabel("ID:", 1, gbc);
        textID = criarCampoMinimo();
        addField(textID, 1, gbc, true);

        addLabel("Nome:", 2, gbc);
        textnome = criarCampoMinimo();
        addField(textnome, 2, gbc, false);

        addLabel("Descrição:", 3, gbc);
        textDesc = criarCampoMinimo();
        addField(textDesc, 3, gbc, false);

        addLabel("Quantidade:", 4, gbc);
        textQtd = criarCampoMinimo();
        addField(textQtd, 4, gbc, true);

        addLabel("Preço:", 5, gbc);
        textpreco = criarCampoMinimo();
        addField(textpreco, 5, gbc, true);

        // -----------------------------------------------------
        // BOTÃO ADICIONAR
        // -----------------------------------------------------
        btn_adicionar = new JButton("Adicionar Produto");
        btn_adicionar.setFont(new Font("Segoe UI", Font.BOLD, 20)); // maior
        btn_adicionar.setPreferredSize(new Dimension(250, 45)); // botão maior
        btn_adicionar.setBackground(new Color(200, 255, 200));

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 3;
        add(btn_adicionar, gbc);

        // -----------------------------------------------------
        // TABELA (TAMANHO MÍNIMO BOM)
        // -----------------------------------------------------
        modeloTabela = new DefaultTableModel(
                new Object[]{"ID", "Nome", "Descrição", "Preço", "Quantidade"}, 0
        );

        tabelaProdutos = new JTable(modeloTabela);
        tabelaProdutos.setFont(new Font("Segoe UI", Font.PLAIN, 16)); // fonte maior
        tabelaProdutos.setRowHeight(28);                             // linhas maiores
        tabelaProdutos.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 18)); 
        tabelaProdutos.getTableHeader().setBackground(new Color(230, 230, 230));
        tabelaProdutos.setSelectionBackground(new Color(210, 230, 255));

        JScrollPane scroll = new JScrollPane(tabelaProdutos);
        scroll.setPreferredSize(new Dimension(650, 450)); // 👈 tabela maior no mínimo!
        scroll.setBorder(new EmptyBorder(10, 10, 10, 10));

        gbc.gridx = 3;
        gbc.gridy = 1;
        gbc.gridheight = 6;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.BOTH;
        add(scroll, gbc);

        configurarValidacoes();
    }

    // ----------------------------------------------------------
    // LABEL
    // ----------------------------------------------------------
    private void addLabel(String texto, int linha, GridBagConstraints gbc) {
        gbc.gridx = 0;
        gbc.gridy = linha;

        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 20)); // fonte maior
        add(lbl, gbc);
    }

    // ----------------------------------------------------------
    // CAMPOS COM TAMANHO MÍNIMO "DE VERDADE"
    // ----------------------------------------------------------
    private JTextField criarCampoMinimo() {
        JTextField campo = new JTextField();
        campo.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        campo.setPreferredSize(new Dimension(260, 35)); // 👈 aumenta aqui
        campo.setMinimumSize(new Dimension(200, 30));
        return campo;
    }

    private void addField(JTextField field, int linha, GridBagConstraints gbc, boolean numero) {
        gbc.gridx = 1;
        gbc.gridy = linha;
        add(field, gbc);

        if (numero) {
            field.addKeyListener(new KeyAdapter() {
                public void keyReleased(KeyEvent e) {
                    if (!field.getText().matches("[0-9.,]*")) {
                        field.setBackground(new Color(255, 180, 180));
                    } else {
                        field.setBackground(Color.WHITE);
                    }
                }
            });
        }
    }

    // ----------------------------------------------------------
    // VALIDAÇÕES
    // ----------------------------------------------------------
    private void configurarValidacoes() {

        textnome.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (!textnome.getText().matches("[A-Za-zÀ-ÿ ]*")) {
                    textnome.setBackground(new Color(255, 180, 180));
                } else {
                    textnome.setBackground(Color.WHITE);
                }
            }
        });

        textDesc.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                if (textDesc.getText().length() > 120) {
                    textDesc.setBackground(new Color(255, 180, 180));
                } else {
                    textDesc.setBackground(Color.WHITE);
                }
            }
        });
    }

    // ----------------------------------------------------------
    // MÉTODOS USADOS PELO CONTROLLER (NÃO ALTERADOS)
    // ----------------------------------------------------------
    public void adicionar(ActionListener a) { btn_adicionar.addActionListener(a); }
    public void voltar(ActionListener a) { btnVoltar.addActionListener(a); }
    public void adicionarOuvinte(ComponentListener c) { addComponentListener(c); }

    public int getId() {
        try { return Integer.parseInt(textID.getText()); }
        catch (Exception e) { return -1; }
    }
    public String getNome() { return textnome.getText(); }
    public String getDescricao() { return textDesc.getText(); }

    public double getPreco() {
        try { return Double.parseDouble(textpreco.getText().replace(",", ".")); }
        catch (Exception e) { return -1; }
    }

    public int getQuantidade() {
        try { return Integer.parseInt(textQtd.getText()); }
        catch (Exception e) { return -1; }
    }

    public void setTextID(String id) { textID.setText(id); }
    public void setTextNome(String nome) { textnome.setText(nome); }
    public void setTextDesc(String desc) { textDesc.setText(desc); }
    public void setTextQtd(String qtd) { textQtd.setText(qtd); }
    public void setTextPreco(String preco) { textpreco.setText(preco); }

    public DefaultTableModel getModeloTabela() { return modeloTabela; }
    public JTable getTabelaProdutos() { return tabelaProdutos; }
}

package views;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.text.ParseException;

public class TelaLogin extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTextField txtNome;
    private JFormattedTextField txtCpf;
    private JButton btnCadastrar, btnLogin;
    private JLabel lblTitulo;

    // Fontes base (tamanho mínimo)
    private int baseFont = 20;
    private int baseFontSmall = 18;
    private int baseFontTitulo = 36;

    public TelaLogin() {

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ---------- TÍTULO ----------
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        lblTitulo = new JLabel("Tela de Login", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Tahoma", Font.BOLD, baseFontTitulo));
        add(lblTitulo, gbc);

        gbc.gridwidth = 1;

        // ---------- LABEL NOME ----------
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        add(lblNome, gbc);

        // ---------- CAMPO NOME ----------
        gbc.gridx = 1;
        txtNome = new JTextField();
        txtNome.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        txtNome.setDocument(soLetras(50));
        add(txtNome, gbc);

        // ---------- LABEL CPF ----------
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        add(lblCpf, gbc);

        // ---------- CAMPO CPF ----------
        gbc.gridx = 1;
        try {
            MaskFormatter mf = new MaskFormatter("###.###.###-##");
            mf.setPlaceholderCharacter('_');
            txtCpf = new JFormattedTextField(mf);
            txtCpf.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        } catch (ParseException e) {
            txtCpf = new JFormattedTextField();
        }
        add(txtCpf, gbc);

        // ---------- BOTÃO LOGIN ----------
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        btnLogin = new JButton("Entrar");
        btnLogin.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        btnLogin.setPreferredSize(new Dimension(220, 50));
        add(btnLogin, gbc);

        // ---------- TEXTO ----------
        gbc.gridy = 4;
        JLabel lblNCdt = new JLabel("Não tem cadastro?");
        lblNCdt.setFont(new Font("Tahoma", Font.PLAIN, baseFontSmall));
        add(lblNCdt, gbc);

        // ---------- BOTÃO CADASTRAR ----------
        gbc.gridy = 5;
        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        btnCadastrar.setPreferredSize(new Dimension(220, 50));
        add(btnCadastrar, gbc);

        // ==========================================================
        // RESPONSIVIDADE APRIMORADA
        // (cresce mais do que antes e inclui o título)
        // ==========================================================
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                aplicarResponsividade();
            }
        });
    }

    // RESPONSIVIDADE MAIS FORTE
    private void aplicarResponsividade() {
        int w = getWidth();
        int h = getHeight();

        int ref = Math.min(w, h);

        // Crescimento aumentado (antes /40, agora mais sensível /32)
        int fontSize = Math.max(baseFont, ref / 32);
        int smallFontSize = Math.max(baseFontSmall, ref / 36);

        int tituloSize = Math.max(baseFontTitulo, ref / 20);

        int btnHeight = Math.max(50, ref / 12);
        int btnFont = Math.max(18, ref / 30);

        Font f = new Font("Tahoma", Font.PLAIN, fontSize);
        Font fSmall = new Font("Tahoma", Font.PLAIN, smallFontSize);
        Font fBtn = new Font("Tahoma", Font.BOLD, btnFont);
        Font fTitulo = new Font("Tahoma", Font.BOLD, tituloSize);

        lblTitulo.setFont(fTitulo);

        for (Component c : getComponents()) {
            if (c instanceof JLabel && c != lblTitulo) c.setFont(fSmall);
            if (c instanceof JTextField) c.setFont(f);
            if (c instanceof JFormattedTextField) c.setFont(f);
            if (c instanceof JButton) {
                c.setFont(fBtn);
                c.setPreferredSize(new Dimension(220, btnHeight));
            }
        }

        revalidate();
        repaint();
    }

    // ==========================================================
    // INPUT FILTER: SOMENTE LETRAS
    // ==========================================================
    private DocumentFilter soLetrasFilter = new DocumentFilter() {
        @Override
        public void insertString(FilterBypass fb, int offset, String text, AttributeSet attr)
                throws BadLocationException {
            if (text.matches("[a-zA-ZÀ-ÿ ]+")) {
                super.insertString(fb, offset, text, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                throws BadLocationException {
            if (text.matches("[a-zA-ZÀ-ÿ ]+")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    };

    private PlainDocument soLetras(int max) {
        PlainDocument doc = new PlainDocument();
        doc.setDocumentFilter(soLetrasFilter);
        return doc;
    }

    // ==========================================================
    // MÉTODOS PARA CONTROLLER
    // ==========================================================
    public void entrar(java.awt.event.ActionListener action) {
        btnLogin.addActionListener(action);
    }

    public void cadastrar(java.awt.event.ActionListener action) {
        btnCadastrar.addActionListener(action);
    }

    public String getNome() {
        return txtNome.getText().trim();
    }

    public String getCpf() {
        return txtCpf.getText().replace("_", "").replace(".", "").replace("-", "").trim();
    }
}

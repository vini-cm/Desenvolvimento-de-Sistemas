package views;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

public class TelaDeCadastro extends JPanel {

    private JTextField textNome;
    private JFormattedTextField textCpf;
    private JButton btnCadastrar;
    private JButton btnVoltar;
    private JLabel lblTitulo;

    // Fontes base (tamanho mínimo)
    private int baseFont = 20;
    private int baseFontSmall = 18;
    private int baseFontTitulo = 36;

    public TelaDeCadastro() {

        setLayout(new GridBagLayout());
        setBackground(Color.WHITE);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        // ==========================================================
        // TÍTULO RESPONSIVO
        // ==========================================================
        lblTitulo = new JLabel("CADASTRO", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI Black", Font.BOLD, baseFontTitulo));

        c.gridx = 0;
        c.gridy = 0;
        c.gridwidth = 2;
        add(lblTitulo, c);

        c.gridwidth = 1;

        // LABEL NOME
        c.gridy++;
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        add(lblNome, c);

        // CAMPO NOME
        textNome = new JTextField();
        textNome.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        c.gridx = 1;
        add(textNome, c);

        // LABEL CPF
        c.gridx = 0;
        c.gridy++;
        JLabel lblCpf = new JLabel("CPF:");
        lblCpf.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        add(lblCpf, c);

        // CAMPO CPF FORMATADO
        textCpf = criarCampoCPF();
        textCpf.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        c.gridx = 1;
        add(textCpf, c);

        // BOTÃO CADASTRAR
        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        btnCadastrar.setPreferredSize(new Dimension(220, 50));
        c.gridx = 0;
        c.gridy++;
        c.gridwidth = 2;
        add(btnCadastrar, c);

        // BOTÃO VOLTAR
        btnVoltar = new JButton("Voltar");
        btnVoltar.setFont(new Font("Tahoma", Font.PLAIN, baseFont));
        btnVoltar.setPreferredSize(new Dimension(220, 50));
        btnVoltar.setBackground(new Color(255, 200, 200));
        c.gridy++;
        add(btnVoltar, c);

        // ==========================================================
        // APLICA RESPONSIVIDADE (EXATAMENTE IGUAL À TELA LOGIN)
        // ==========================================================
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                aplicarResponsividade();
            }
        });
    }

    private void aplicarResponsividade() {

        int w = getWidth();
        int h = getHeight();

        int ref = Math.min(w, h);

        // Crescimento mais forte (igual na TelaLogin responsiva)
        int fontSize = Math.max(baseFont, ref / 32);
        int smallFontSize = Math.max(baseFontSmall, ref / 36);
        int tituloSize = Math.max(baseFontTitulo, ref / 20);

        int btnHeight = Math.max(50, ref / 12);
        int btnFont = Math.max(18, ref / 30);

        Font f = new Font("Tahoma", Font.PLAIN, fontSize);
        Font fSmall = new Font("Tahoma", Font.PLAIN, smallFontSize);
        Font fBtn = new Font("Tahoma", Font.BOLD, btnFont);
        Font fTitulo = new Font("Segoe UI Black", Font.BOLD, tituloSize);

        lblTitulo.setFont(fTitulo);

        for (Component comp : getComponents()) {

            if (comp instanceof JLabel && comp != lblTitulo)
                comp.setFont(fSmall);

            if (comp instanceof JTextField || comp instanceof JFormattedTextField)
                comp.setFont(f);

            if (comp instanceof JButton) {
                comp.setFont(fBtn);
                comp.setPreferredSize(new Dimension(220, btnHeight));
            }
        }

        revalidate();
        repaint();
    }

    // ==========================================================
    // CAMPO CPF FORMATADO
    // ==========================================================
    private JFormattedTextField criarCampoCPF() {
        try {
            MaskFormatter mask = new MaskFormatter("###.###.###-##");
            mask.setPlaceholderCharacter('_');
            return new JFormattedTextField(mask);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao criar máscara CPF");
        }
    }

    // ==========================================================
    // MÉTODOS PARA CONTROLLER
    // ==========================================================
    public void cadastrar(ActionListener al) {
        btnCadastrar.addActionListener(al);
    }

    public void voltar(ActionListener al) {
        btnVoltar.addActionListener(al);
    }

    public String getNome() {
        return textNome.getText().trim();
    }

    public String getCpf() {
        return textCpf.getText().replaceAll("[^0-9]", "");
    }

}

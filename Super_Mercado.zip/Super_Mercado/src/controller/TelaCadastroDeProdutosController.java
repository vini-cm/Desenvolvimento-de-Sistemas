package controller;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Model.Produto;
import Model.ProdutoDAO;
import views.TelaCadastroDeProdutos;

public class TelaCadastroDeProdutosController {

    private TelaCadastroDeProdutos view;
    private ProdutoDAO model;
    private Navegador navegador;

    public TelaCadastroDeProdutosController(TelaCadastroDeProdutos view, ProdutoDAO model, Navegador navegador) {
        this.view = view;
        this.model = model;
        this.navegador = navegador;

        // ---- BOTÃO ADICIONAR ----
        view.adicionar(e -> validarESalvar());

        // ---- VOLTAR ----
        view.voltar(e -> navegador.navegarPara("TELA LOGIN"));

        // Atualizar tabela ao abrir
        view.adicionarOuvinte(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent e) {
                atualizarTabela();
            }
        });
    }

    private void validarESalvar() {

        int id = view.getId();
        String nome = view.getNome();
        String desc = view.getDescricao();
        double preco = view.getPreco();
        int quantidade = view.getQuantidade();

        // ----- validações -----

        if (id <= 0) {
            erro("O ID deve conter apenas números e ser maior que zero.");
            return;
        }

        if (nome.isBlank() || !nome.matches("[A-Za-zÀ-ÿ ]+")) {
            erro("O nome deve conter apenas letras.");
            return;
        }

        if (desc.length() < 3 || desc.length() > 120) {
            erro("Descrição deve ter entre 3 e 120 caracteres.");
            return;
        }

        if (preco <= 0) {
            erro("O preço deve ser maior que 0.");
            return;
        }

        if (quantidade <= 0) {
            erro("Quantidade deve ser maior que 0.");
            return;
        }

        // Já existe?
        if (model.pesquisarProduto(id) != null) {
            erro("Já existe produto com esse ID.");
            return;
        }

        Produto p = new Produto(id, nome, desc, preco, quantidade);
        model.adicionarProduto(p);

        sucesso("Produto cadastrado com sucesso!");
        atualizarTabela();
        limparCampos();
    }

    private void atualizarTabela() {
        DefaultTableModel t = view.getModeloTabela();
        t.setRowCount(0);

        List<Produto> lista = model.listarProdutos();

        for (Produto p : lista) {
            t.addRow(new Object[]{
                    p.getId(),
                    p.getNome(),
                    p.getDescricao(),
                    p.getPreco(),
                    p.getQuantidade()
            });
        }
    }

    private void limparCampos() {
        view.setTextID("");
        view.setTextNome("");
        view.setTextDesc("");
        view.setTextQtd("");
        view.setTextPreco("");
    }

    private void erro(String m) {
        JOptionPane.showMessageDialog(null, m, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    private void sucesso(String m) {
        JOptionPane.showMessageDialog(null, m, "Sucesso", JOptionPane.INFORMATION_MESSAGE);
    }
}

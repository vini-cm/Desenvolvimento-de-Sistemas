package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ComponentListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Model.Produto;
import Model.ProdutoDAO;

public class TelaCadastroDeProdutos extends JPanel {

    private static final long serialVersionUID = 1L;
    private JButton btn_adicionar;
    private JTextField textID;
    private JTextField textnome;
    private JTextField textDesc;
    private JTextField textQtd;
    private JTextField textpreco;
    private DefaultTableModel modeloTabela;
    private DefaultTableModel modeloCarrinho;
    

    public TelaCadastroDeProdutos() {
        setPreferredSize(new Dimension(450, 350));
        setBackground(new Color(255, 255, 255));
        setLayout(null);

        JLabel lblTitulo = new JLabel("CADASTRAR PRODUTO");
        lblTitulo.setFont(new Font("Segoe UI Black", Font.PLAIN, 25));
        lblTitulo.setBounds(42, 11, 312, 52);
        add(lblTitulo);

        JLabel lblNewLabel = new JLabel("ID");
        lblNewLabel.setBounds(56, 77, 46, 14);
        add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Nome");
        lblNewLabel_1.setBounds(56, 102, 46, 14);
        add(lblNewLabel_1);

        JLabel lblNewLabel_1_1 = new JLabel("Descrição");
        lblNewLabel_1_1.setBounds(56, 127, 86, 14);
        add(lblNewLabel_1_1);

        JLabel lblNewLabel_1_1_2 = new JLabel("Quantidade");
        lblNewLabel_1_1_2.setBounds(56, 152, 86, 16);
        add(lblNewLabel_1_1_2);

        JLabel lblNewLabel_1_1_1 = new JLabel("Preço");
        lblNewLabel_1_1_1.setBounds(56, 179, 46, 14);
        add(lblNewLabel_1_1_1);

        textID = new JTextField();
        textID.setBounds(181, 74, 86, 20);
        add(textID);
        textID.setColumns(10);

        textnome = new JTextField();
        textnome.setBounds(181, 99, 86, 20);
        add(textnome);
        textnome.setColumns(10);

        textDesc = new JTextField();
        textDesc.setBounds(181, 124, 86, 20);
        add(textDesc);
        textDesc.setColumns(10);

        textQtd = new JTextField();
        textQtd.setBounds(181, 150, 86, 20);
        add(textQtd);
        textQtd.setColumns(10);

        textpreco = new JTextField();
        textpreco.setBounds(181, 176, 86, 20);
        add(textpreco);
        textpreco.setColumns(10);

        btn_adicionar = new JButton("Adicionar Produto");
        btn_adicionar.setBounds(107, 234, 160, 30);
        add(btn_adicionar);
        
     // Debug: mostra identidade da view e captura clique direto na view
        System.out.println("[VIEW ctor] this=" + System.identityHashCode(this));
        btn_adicionar.setOpaque(true);               // força a aparência (ajuda se estiver encoberto)
        btn_adicionar.setBackground(Color.RED);     // visualmente fácil de ver se está por cima
        btn_adicionar.addActionListener(e ->
            System.out.println("[VIEW] botão clicado (listener interno)")
        );

    }
    

    // Método para adicionar o listener do botão
    public void adicionar(ActionListener actionListener) {
        System.out.println("[VIEW] adicionar() chamado. view=" + System.identityHashCode(this)
            + " listener=" + actionListener.getClass().getName());
        this.btn_adicionar.addActionListener(actionListener);
    }


    // Caso precise adicionar ouvintes de componente (troca de tela, etc)
    public void adicionarOuvinte(ComponentListener listener) {
        this.addComponentListener(listener);
    }

    // ======== Getters corrigidos (agora pegam o texto atual dos campos) ========

    public int getId() {
        try {
            return Integer.parseInt(textID.getText());
        } catch (Exception e) {
            return 0;
        }
    }

    public String getNome() {
        return textnome.getText();
    }

    public String getDescricao() {
        return textDesc.getText();
    }

    public double getPreco() {
        try {
            return Double.parseDouble(textpreco.getText());
        } catch (Exception e) {
            return 0.0;
        }
    }

    public int getQuantidade() {
        try {
            return Integer.parseInt(textQtd.getText());
        } catch (Exception e) {
            return 0;
        }
    }

    // ======== Setters (caso queira preencher campos automaticamente) ========

    public void setTextID(String id) {
        this.textID.setText(id);
    }

    public void setTextNome(String nome) {
        this.textnome.setText(nome);
    }

    public void setTextDesc(String desc) {
        this.textDesc.setText(desc);
    }

    public void setTextQtd(String qtd) {
        this.textQtd.setText(qtd);
    }

    public void setTextPreco(String preco) {
        this.textpreco.setText(preco);
    }
    public void atualizarLista() {
        ProdutoDAO dao = new ProdutoDAO();
        List<Produto> produtos = dao.listarProdutos();

        for (Produto p : produtos) {
         
                p.getId(); p.getNome(); p.getDescricao(); p.getPreco(); p.getQuantidade();
            
        }
    }
    
}

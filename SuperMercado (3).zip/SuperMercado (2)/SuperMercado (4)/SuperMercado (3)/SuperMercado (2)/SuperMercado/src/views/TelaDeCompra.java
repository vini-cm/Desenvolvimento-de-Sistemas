package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ComponentListener;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Model.Produto;
import Model.ProdutoDAO;
import Model.Usuario;
import controller.TelaDeCompraController;

public class TelaDeCompra extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTable tabelaProdutos;
    private DefaultTableModel modeloTabela;
    private JTable tabelaCarrinho;
    private DefaultTableModel modeloCarrinho;
    private JLabel lblTotal;
    private JLabel lblUsuario;   // ✅ Agora é atributo da classe
    private Usuario usuarioLogado;
    private JList list_Produtos;
    private DefaultListModel<String> jlist_Produtos_model;
    private TelaDeCompraController controller;

    // ====== CONSTRUTOR VAZIO ======
    public TelaDeCompra() {
        this(null);
    }

    // ====== CONSTRUTOR COM USUÁRIO ======
    public TelaDeCompra(Usuario usuarioLogado) {
        setLayout(null);
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(700, 500));

        JLabel lblTitulo = new JLabel("TELA DE COMPRA");
        lblTitulo.setFont(new Font("Segoe UI Black", Font.PLAIN, 25));
        lblTitulo.setBounds(230, 10, 300, 30);
        add(lblTitulo);

        lblUsuario = new JLabel();
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUsuario.setBounds(30, 45, 500, 20);
        add(lblUsuario);

        if (usuarioLogado != null) {
            setUsuarioLogado(usuarioLogado);
        }

        // ====== TABELA DE PRODUTOS ======
        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Descrição", "Preço", "Estoque"}, 0);
        tabelaProdutos = new JTable(modeloTabela);
        JScrollPane scrollProdutos = new JScrollPane(tabelaProdutos);
        scrollProdutos.setBounds(30, 70, 620, 150);
        add(scrollProdutos);

        JButton btnAdicionar = new JButton("Adicionar ao Carrinho");
        btnAdicionar.setBounds(250, 230, 200, 30);
        add(btnAdicionar);

        // ====== TABELA DE CARRINHO ======
        modeloCarrinho = new DefaultTableModel(new Object[]{"ID", "Nome", "Preço", "Qtd", "Subtotal"}, 0);
        tabelaCarrinho = new JTable(modeloCarrinho);
        JScrollPane scrollCarrinho = new JScrollPane(tabelaCarrinho);
        scrollCarrinho.setBounds(30, 270, 620, 130);
        add(scrollCarrinho);

        JButton btnRemover = new JButton("Remover do Carrinho");
        btnRemover.setBounds(250, 410, 200, 30);
        add(btnRemover);

        lblTotal = new JLabel("Total: R$ 0.00");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotal.setBounds(480, 450, 200, 30);
        add(lblTotal);

        JButton btnNota = new JButton("Emitir Nota Fiscal");
        btnNota.setBounds(250, 450, 200, 30);
        add(btnNota);

        // === Inicializa o controller ===
        controller = new TelaDeCompraController(modeloTabela, modeloCarrinho, lblTotal, usuarioLogado);
        controller.atualizarLista();
  

        // === Eventos ===
        btnAdicionar.addActionListener(e -> controller.adicionarAoCarrinho(tabelaProdutos));
        btnRemover.addActionListener(e -> controller.removerDoCarrinho(tabelaCarrinho));
        btnNota.addActionListener(e -> controller.emitirNotaFiscal());
    }
    public void adicionarOuvinte(ComponentListener listener) {
		this.addComponentListener(listener);
	}
    public void setUsuarioLogado(Usuario usuario) {
        this.usuarioLogado = usuario;
        lblUsuario.setText("Usuário: " + usuario.getNome() + " | CPF: " + usuario.getCpf());
        controller.setUsuario(usuario);
    }
    public void setJLists(List<Produto> produto) {
		this.jlist_Produtos_model.clear();

		for (Produto c : produto) {
			this.jlist_Produtos_model.addElement(String.valueOf(c.getId()));
			
		}
	}
    public void atualizarLista() {
        modeloTabela.setRowCount(0);
        ProdutoDAO dao = new ProdutoDAO();
        List<Produto> produtos = dao.listarProdutos();

        for (Produto p : produtos) {
            modeloTabela.addRow(new Object[]{
                p.getId(), p.getNome(), p.getDescricao(), p.getPreco(), p.getQuantidade()
            });
        }
    }
}

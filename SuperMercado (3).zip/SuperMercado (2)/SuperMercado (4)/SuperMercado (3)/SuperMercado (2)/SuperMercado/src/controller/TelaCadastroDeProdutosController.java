package controller;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Model.Produto;
import Model.ProdutoDAO;
import views.TelaCadastroDeProdutos;

public class TelaCadastroDeProdutosController {
    private final TelaCadastroDeProdutos view;
    private final ProdutoDAO model;
    private final Navegador navegador;
    
    
    
    
    
    public TelaCadastroDeProdutosController(TelaCadastroDeProdutos view, ProdutoDAO model, Navegador navegador) {
        this.view = view;
        this.model = model;
        this.navegador = navegador;
        view.atualizarLista();
        System.out.println("[CONTROLLER] actionPerformed rodando. view=" + System.identityHashCode(this.view));
        List<Produto> lista = this.model.listarProdutos();
        this.view.adicionar(e -> {
            System.out.println("[CONTROLLER] actionPerformed rodando");
            int id = this.view.getId();
            String nome = this.view.getNome();
            String descricao = this.view.getDescricao();
            double preco = this.view.getPreco();
            int quantidade = this.view.getQuantidade();

            System.out.println("[CONTROLLER] valores lidos: id=" + id + " nome=" + nome + " preco=" + preco + " qtd=" + quantidade);

            if(nome != null && !nome.isBlank() &&
               descricao != null && !descricao.isBlank() &&
               id != 0 && preco != 0 && quantidade != 0) {

                Produto existente = this.model.pesquisarProduto(id);
                if(existente != null) {
                    JOptionPane.showMessageDialog(null, "Produto já existente!", "Erro", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Produto produto = new Produto(id, nome, descricao, preco, quantidade);
                this.model.adicionarProduto(produto);

                if(this.model.pesquisarProduto(id) != null) {
                    JOptionPane.showMessageDialog(null, "CADASTRO REALIZADO COM SUCESSO", "CADASTRO!", JOptionPane.INFORMATION_MESSAGE);
                  
                    this.navegador.navegarPara("TELA DE COMPRA");
                    System.out.println("olaaaaa");
                } else {
                    JOptionPane.showMessageDialog(null, "Algum erro no cadastro", "Problema", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Preencha todos os campos corretamente", "Erro", JOptionPane.WARNING_MESSAGE);
            }
        });
        
    }
}

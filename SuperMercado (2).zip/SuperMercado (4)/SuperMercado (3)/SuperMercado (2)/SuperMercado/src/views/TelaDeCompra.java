package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import Model.Usuario;
import controller.TelaDeCompraController;

public class TelaDeCompra extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTable tabelaProdutos;
    private DefaultTableModel modeloTabela;
    private JTable tabelaCarrinho;
    private DefaultTableModel modeloCarrinho;
    private JLabel lblTotal;
    private Usuario usuarioLogado;

    private TelaDeCompraController controller;

    public TelaDeCompra(Usuario usuarioLogado) {
        setLayout(null);
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(700, 500));

        JLabel lblTitulo = new JLabel("TELA DE COMPRA");
        lblTitulo.setFont(new Font("Segoe UI Black", Font.PLAIN, 25));
        lblTitulo.setBounds(230, 10, 300, 30);
        add(lblTitulo);

        JLabel lblUsuario = new JLabel("Usuário: " + usuarioLogado.getNome() + " | CPF: " + usuarioLogado.getCpf());
        lblUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblUsuario.setBounds(30, 45, 500, 20);
        add(lblUsuario);

        // ====== TABELA DE PRODUTOS ======
        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Descrição", "Preço", "Estoque"}, 0);
        tabelaProdutos = new JTable(modeloTabela);
        JScrollPane scrollProdutos = new JScrollPane(tabelaProdutos);
        scrollProdutos.setBounds(30, 70, 620, 150);
        add(scrollProdutos);

        JButton btnAdicionar = new JButton("Adicionar ao Carrinho");
        btnAdicionar.setBounds(250, 230, 200, 30);
        add(btnAdicionar);

        // ====== TABELA DE CARRINHO ======
        modeloCarrinho = new DefaultTableModel(new Object[]{"ID", "Nome", "Preço", "Qtd", "Subtotal"}, 0);
        tabelaCarrinho = new JTable(modeloCarrinho);
        JScrollPane scrollCarrinho = new JScrollPane(tabelaCarrinho);
        scrollCarrinho.setBounds(30, 270, 620, 130);
        add(scrollCarrinho);

        JButton btnRemover = new JButton("Remover do Carrinho");
        btnRemover.setBounds(250, 410, 200, 30);
        add(btnRemover);

        lblTotal = new JLabel("Total: R$ 0.00");
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotal.setBounds(480, 450, 200, 30);
        add(lblTotal);

        JButton btnNota = new JButton("Emitir Nota Fiscal");
        btnNota.setBounds(250, 450, 200, 30);
        add(btnNota);

        // === Inicializa o controller ===
        controller = new TelaDeCompraController(modeloTabela, modeloCarrinho, lblTotal, usuarioLogado);
        controller.atualizarLista();

        // === Eventos ===
        btnAdicionar.addActionListener(e -> controller.adicionarAoCarrinho(tabelaProdutos));
        btnRemover.addActionListener(e -> controller.removerDoCarrinho(tabelaCarrinho));
        btnNota.addActionListener(e -> controller.emitirNotaFiscal());
    }
    public void setUsuarioLogado(Usuario usuario) {
        this.usuarioLogado = usuario;
        // Atualiza label do usuário
        lblUsuario.setText("Usuário: " + usuario.getNome() + " | CPF: " + usuario.getCpf());
    }
}

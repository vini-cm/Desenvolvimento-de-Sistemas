package controller;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Model.Produto;
import Model.ProdutoDAO;
import Model.Usuario;
import views.TelaCadastroDeProdutos;

public class TelaCadastroDeProdutosController {
	private final TelaCadastroDeProdutos view;
	private final ProdutoDAO model;
	private final Navegador navegador;
	
	public TelaCadastroDeProdutosController(TelaCadastroDeProdutos view, ProdutoDAO model, Navegador navegador) {
		this.view = view;
		this.model = model;
		this.navegador = navegador;
		
		List<Produto> lista = this.model.listarProdutos();
		this.view.adicionar(e -> {
			int id = this.view.getId();
			String nome = this.view.getNome();
			String descricao = this.view.getDescricao();
			double preco = this.view.getPreco();
			int quantidade = this.view.getQuantidade();
			if(nome != null || !nome.isBlank() || !nome.isEmpty() ||
					id != 0 || descricao != null || !descricao.isBlank()|| !descricao.isEmpty()||
					preco != 0 || quantidade != 0 ) {
				Produto existente = this.model.pesquisarProduto(id);
				if(existente != null) {
						JPanel painel = new JPanel();
						JOptionPane.showMessageDialog(
			                    painel, // Componente pai (opcional, mas recomendado)
			                    "Produto Ja Existente", // Mensagem
			                    "Título do Alerta", // Título da janela
			                    JOptionPane.WARNING_MESSAGE // Tipo da mensagem (ícone)
			            );
				}
				Produto produto = new Produto(id, nome, descricao, preco, quantidade);
				model.adicionarProduto(produto);
				if(this.model.pesquisarProduto(id)!= null) {
					JOptionPane.showMessageDialog(null, "CADASTRO!", "CADASTRO REALIZADO COM SUCESSO", JOptionPane.WARNING_MESSAGE);
					this.navegador.navegarPara("TELA DE COMPRA");
					System.out.println("olaaaaa");
				}
				
				else {
					JOptionPane.showMessageDialog(null, "Algum erro no Cadastro", "Problema", JOptionPane.INFORMATION_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Prencha todos os Campos", "Erro", JOptionPane.WARNING_MESSAGE);
			}

		});
	}
	
	
}

